# genere la javadoc
 javadoc -docencoding latin1 -d doc -sourcepath src calcul.analyseurs