javac -d classes `ls */calcul/*/*.java`
