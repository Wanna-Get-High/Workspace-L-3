package ressource;

/**
 * The Class Panier.
 */
public class Panier implements Resource 
{
	
	/**
	 * Instantiates a new panier.
	 */
	public Panier(){}
	
	@Override
	public String description() 
	{
		return "Panier";
	}
}