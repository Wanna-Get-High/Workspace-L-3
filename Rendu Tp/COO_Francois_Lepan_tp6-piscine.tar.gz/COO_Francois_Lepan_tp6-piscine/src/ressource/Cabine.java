package ressource;

/**
 * The Class Cabine.
 */
public class Cabine implements Resource 
{
	
	/**
	 * Instantiates a new cabine.
	 */
	public Cabine(){}
	
	@Override
	public String description() 
	{
		return "Cabine";
	}

}
