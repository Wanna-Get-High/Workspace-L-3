package ressource;

/**
 * The Class InvalidResourceExecption.
 */
public class InvalidResourceException 
{
	/**
	 * Instantiates a new invalid resource exception.
	 *
	 * @param msg the message
	 */
	public InvalidResourceException(String msg)
	{
		System.err.println(msg);
	}
}