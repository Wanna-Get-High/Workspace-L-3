package action;

public enum ActionState {
	notStarted,started,finished
}
