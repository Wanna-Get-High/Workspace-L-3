javac -d classes src/init/*/*.java
