# génération des lexer et parser

cd spec
java org.antlr.Tool Init.g -o ../src/init/analyseurs
