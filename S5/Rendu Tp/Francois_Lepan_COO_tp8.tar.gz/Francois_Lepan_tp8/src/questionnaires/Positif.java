package questionnaires;

public enum Positif 
{	
	oui,non
}