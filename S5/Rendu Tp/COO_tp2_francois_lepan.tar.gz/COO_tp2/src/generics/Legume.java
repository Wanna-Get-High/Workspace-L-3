package generics;

public interface Legume {}
