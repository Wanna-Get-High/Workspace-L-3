accoler([] ,L,L).
accoler([T|Q],L2,[T|L3]) :- accoler(Q,L2,L3).

prefixe(P,L) :- accoler(P, _, L).
suffixe(S,L) :- accoler(_,S,L).

sous_liste(SubList, List) :- suffixe(S,List), prefixe(SubList, S).

inv([] ,[]).
inv([T|Q],R) :- inv(Q,InvQ), accoler(InvQ,[T],R).

accInv([T|Q], A, R) :- accInv(Q, [T|A], R).
accInv([], A, A).
inverser(L, R) :- accInv(L, [] ,R).

trainDirect(dunkerque,bergues).
trainDirect(bergues,hazebrouck).
trainDirect(hazebrouck,lens).
trainDirect(hazebrouck,lille).
trainDirect(lens,lille).
trainDirect(lens,douai).
trainDirect(douai,lille).
trainDirect(lille,lezennes).

voyagerDe(X,Y) :- trainDirect(X,Y).
voyagerDe(X,Y) :- trainDirect(X,Z), voyagerDe(Z,Y).
voyagerDe(X,Y) :- trainDirect(Y,X).
voyagerDe(X,Y) :- trainDirect(Z,X), voyagerDe(Z,Y).

route(X, Y, [Y]) :- trainDirect(X, Y).
route(X, Y, [Y]) :- trainDirect(Y, X).
route(X, Y, [X|R]) :- trainDirect(X,Z), route(Y, Z, R).
route(X, Y, [X|R]) :- trainDirect(Z,X), route(Y, Z, R).