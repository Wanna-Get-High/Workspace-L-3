/*
 * stat.h
 *
 *  Created on: Mar 24, 2012
 *      Author: benjamin
 */

#ifndef STAT_H_
#define STAT_H_

#include "config.h"
#include <pthread.h>

static volatile int nb_lignes_recues[MAX_CONNECTION];

volatile static int nb_max_clients = 0;
volatile static int nb_max_lignes_recues = 0;
volatile static int nb_max_lignes_envoyees = 0;

pthread_mutex_t nb_lignes_recues_mutex;
pthread_mutex_t nb_max_clients_mutex;
pthread_mutex_t nb_max_lignes_recues_mutex;
pthread_mutex_t nb_max_lignes_envoyees_mutex;

pthread_mutex_t lignes_recues_mutex;
pthread_mutex_t lignes_envoyees_mutex;

void increment_nb_lignes_pour(int sckt);
void initialize_mutexes();
void set_nb_max_clients();
void check_nb_max_lignes_envoyees(int nb_de_lignes_envoyees);
int index_of_socket(int sckt,int* sock);
void check_nb_max_lignes_recues(int nb_de_lignes_recues);
void statistics(int e, int r, int sockets[MAX_CONNECTION]);
void check_nb_max_lignes_envoyees(int nb_de_lignes_envoyees);
#endif /* STAT_H_ */
