/*
 * stat.c
 *
 *  Created on: Mar 24, 2012
 *      Author: benjamin
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <errno.h>

#include "stat.h"
#include "config.h"
#include "tools.h"
#include "cnct.h"


void initialize_mutexes()
{
	int i;
	pthread_mutex_init(&nb_lignes_recues_mutex, NULL);
	pthread_mutex_init(&nb_max_clients_mutex,NULL);
	pthread_mutex_init(&nb_max_lignes_recues_mutex,NULL);
	pthread_mutex_init(&nb_max_lignes_envoyees_mutex,NULL);

	pthread_mutex_init(&lignes_envoyees_mutex,NULL);
	pthread_mutex_init(&lignes_recues_mutex,NULL);

	for (i=0; i < MAX_CONNECTION ; i ++){
		nb_lignes_recues[i]=0;
	}
}

int nb_clients(int sockets[MAX_CONNECTION])
{
	int i;
	int cpt=0;
	pthread_mutex_lock(&sockets_mutex);
	for(i=0 ;i<MAX_CONNECTION;i++)
	{
		if (sockets[i]) cpt++;
	}
	pthread_mutex_unlock(&sockets_mutex);
	return cpt;
}


void set_nb_max_clients(int sockets[MAX_CONNECTION])
{
	int current_nb_clients = nb_clients(sockets);

	if  (nb_max_clients < current_nb_clients)
	{
		pthread_mutex_lock(&nb_max_clients_mutex);
		nb_max_clients = current_nb_clients;
		pthread_mutex_unlock(&nb_max_clients_mutex);
	}
}


int index_of_socket(int sckt,int* sock){
	int i=0;
	pthread_mutex_lock(&sockets_mutex);
	for ( i = 0 ; i < MAX_CONNECTION; i ++){
		if (sock[i] == sckt){
			break;
		}
	}
	pthread_mutex_unlock(&sockets_mutex);
	assert(i < MAX_CONNECTION);
	return i;
}

void increment_nb_lignes_pour(int index){
	pthread_mutex_lock(&nb_lignes_recues_mutex);
	int value = nb_lignes_recues[index];
	nb_lignes_recues[index] = ++value;
	pthread_mutex_unlock(&nb_lignes_recues_mutex);
	check_nb_max_lignes_recues(value);
}

int nb_lignes_pour(int sckt, int socks[MAX_CONNECTION]){
	int i = index_of_socket(sckt, socks);
	pthread_mutex_lock(&nb_lignes_recues_mutex);
	int size = nb_lignes_recues[i];
	pthread_mutex_unlock(&nb_lignes_recues_mutex);
	return size;
}

void check_nb_max_lignes_envoyees(int nb_de_lignes_envoyees){
	pthread_mutex_lock(&nb_max_lignes_envoyees_mutex);
	if ( nb_max_lignes_envoyees < nb_de_lignes_envoyees) nb_max_lignes_envoyees = nb_de_lignes_envoyees;
	pthread_mutex_unlock(&nb_max_lignes_envoyees_mutex);
}

void check_nb_max_lignes_recues(int nb_de_lignes_recues){
	pthread_mutex_lock(&nb_max_lignes_recues_mutex);
	if ( nb_max_lignes_recues < nb_de_lignes_recues) nb_max_lignes_recues = nb_de_lignes_recues;
	pthread_mutex_unlock(&nb_max_lignes_recues_mutex);
}

void statistics(int e, int r, int sockets[MAX_CONNECTION]){
	printf("Nb lignes envoyees en tout: %d\n", e);
	pthread_mutex_lock(&nb_max_lignes_envoyees_mutex);
	printf("Nb MAX lignes envoyees par un client: %d\n", nb_max_lignes_envoyees);
	pthread_mutex_unlock(&nb_max_lignes_envoyees_mutex);
	printf("Nb lignes recues en tout: %d\n", r);
	pthread_mutex_lock(&nb_max_lignes_recues_mutex);
	printf("Nb MAX lignes recues par un client: %d\n", nb_max_lignes_recues);
	pthread_mutex_unlock(&nb_max_lignes_recues_mutex);
	printf("Nb clients: %d\n",  nb_clients(sockets));
	pthread_mutex_lock(&nb_max_clients_mutex);
	printf("Nb MAX clients: %d\n", nb_max_clients);
	pthread_mutex_unlock(&nb_max_clients_mutex);
}
